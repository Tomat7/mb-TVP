#pragma once
#define SKETCHFILE __FILE__ " "
#define SKETCHTIME __DATE__ " " __TIME__
#define MB_TIMEOUT 70       // как долго можно работать/кликать_клапаном без мастера Модбаса (секунды)
#define SERIALSPEED 115200  // скорость в последовательном порту
#define SERIAL_CONFIG       // если нужно выдать только конфигурацию в Serial
//#define SERIAL_INFO         // если нужно постоянно выдавать информацию в Serial
//#define SERIAL_DEBUG        // доп. информация в Serial и в регистры Модбаса ** нужно поправить библиотеки! **

#ifndef DS_CONVTIME
#define DS_CONVTIME 800     // как часто опрашивать DS18B20 (миллисекунды)
#endif

#include "Modbus.h"
ModbusIP mb;

#ifdef DSPINS
#include "DStemp.h"
DSThermometer ds18b20[] = DSPINS;
const int nSensor = sizeof(ds18b20) / sizeof(DSThermometer);  // считаем количество DS'ок
#elif defined(DHTPIN)
#include "dhtnew.h"
DHTNEW dht(DHTPIN);
const int nSensor = 1;
#endif

#include "HDvalve.h"
Valve valve[] = VALVEPINS;

#ifdef PRESSURE_BMP
#include "BMP280x.h"
BMP280x bmp280(BMP280_ADDRESS);
#endif

/*
#ifdef PRESSURE_MPX
#include "MPX5010x.h"
MPX5010x mpx5010dp(MPX5010_PIN);
#endif
*/
#ifdef PRESSURE_MPX
#include "ADCmulti.h"
ADCmulti mpx5010dp(MPX5010_PIN);
//int Pins[] = { MPX5010_PIN };
//int Vals[] = { &mpxRAW };
#endif

// ===
#ifdef USE_OLED
#include "ASOLED.h"
ASOLED LD(SH1106, 100000);
#if defined(OLED_SH1106)
#define LCDX1 0           // смещение 1-го "столбца" на экране
#define LCDX2 65          // смещение 2-го "столбца" на экране
#else
#define LCDX1 1           // смещение 1-го "столбца" на экране
#define LCDX2 67          // смещение 2-го "столбца" на экране
#endif  // OLED_SH1106
#endif  // USE_OLED

// ===
#ifdef USE_LCD
#include "LiquidCrystal_I2C.h"
LiquidCrystal_I2C LCD(0x27,20,4);  // set the LCD address to 0x27 for a 16 chars and 2 line display
#define LCDX1 0           // смещение 1-го "столбца" на экране
#define LCDX2 10          // смещение 2-го "столбца" на экране
#endif  // USE_LCD

#ifndef LCDX1
#define LCDX1 0           // смещение 1-го "столбца" на экране
#define LCDX2 10          // смещение 2-го "столбца" на экране
#endif

// ===
#define hrSECONDS 0                   // регистр-счетчик секунд uptime'а
#define hrTEMP hrSECONDS + 1          // первый регистр с температурой
#define hrPRESSURE hrTEMP + nSensor   // регистр давления
#define hrOPEN hrPRESSURE + 1         // первый регистр с данными для/от клапанов
#define hrCLOSE hrOPEN + 1            // "базовая" скорость - объем собранный за 1000 кликов
#define hrCLICKS hrOPEN + 2           // количество кликов с момента включения
// ===
#define hrDSCONVTIME hrOPEN + nValve*3      // DEBUG!!, таймаут на преобразование DS (можно менять удаленно)   
#define hrDSDEBUG hrDSCONVTIME + 1          // DEBUG!!, будем хранить время преобразования каждой DS'ки
#define hrVALVEDEBUG hrDSDEBUG + nSensor    // DEBUG!!, будем хранить длительность открытия каждого клапана
// ===

const int nValve = sizeof(valve) / sizeof(Valve);             // считаем количество клапанов

unsigned long msReinit;
uint16_t msGet, msLcd;
uint16_t msTimeout = DS_CONVTIME;
const char degC = 223;
char cbuf[] = { "     " };
bool mbMasterOK;
bool modbusON;
bool relayON = false;
int16_t tickToRelayOff = 0;
const char *OTA_pass = String(WIFI_PASS + String(PLC_ID)).c_str();
float t0 = 1;
int h0 = 2;

#ifdef SMART_RELAY
#define RELAY_POWERON_MINS 5 // in minutes
#include <ReadDigKey.h>
ReadDigKey key;
#endif  // SMART_RELAY
    
