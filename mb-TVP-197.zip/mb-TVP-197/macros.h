#pragma once

#ifdef USE_OLED
//#define display_Init() LD.init()
//#define display_Clear() LD.clearDisplay()
#define LD_printNumber(a) LD.printNumber(a)
#define LD_printString_6x8(a,b,c) LD.printString_6x8(a, b, c)
//#define display_String(a,b,c) LD.printString_12x16(a, b, c)
#define LD_printChar_6x8(a) LD.printString_6x8(a)
#define LD_printChar_12x16(a) LD.printString_12x16(a)
#else
//#define display_Init()
//#define display_Clear()
#define LD_printNumber(a)
#define LD_printString_6x8(a,b,c)
//#define display_String(a,b,c)
#define LD_printChar_6x8(a)
#define LD_printChar_12x16(a)
#endif  // USE_OLED

#ifdef SERIAL_INFO
#ifndef SERIAL_CONFIG
#define SERIAL_CONFIG
#endif  // !SERIAL_CONFIG
#define PRINTLN(...) (Serial.println(__VA_ARGS__))
#define PRINT(...) (Serial.print(__VA_ARGS__))
#else
#define PRINTLN(xArg)
#define PRINT(zArg)
#endif  // SERIAL_INFO

#ifdef SERIAL_CONFIG
#define CFG_PRINTLN(...) (Serial.println(__VA_ARGS__))
#define CFG_PRINT(...) (Serial.print(__VA_ARGS__))
#else
#define CFG_PRINTLN(xArg)
#define CFG_PRINT(zArg)
#endif  // SERIAL_CONFIG

#ifdef SERIAL_DEBUG
#define DBG_PRINTLN(...) (Serial.println(__VA_ARGS__))
#define DBG_PRINT(...) (Serial.print(__VA_ARGS__))
#else
#define DBG_PRINTLN(xArg)
#define DBG_PRINT(zArg)
#endif  // SERIAL_DEBUG

#ifdef SMART_RELAY
#define MODE_LOCAL 0, 0
#define MODE_SEARCH_WIFI 100, 100
#define MODE_MODBUS_WAIT 100, 1500
#define MODE_MODBUS_OK 1500, 1500
//#define INFOLED_STATUS(...) valve[IDX_INFOLED].setTime(__VA_ARGS__)
#define RELAY_ON 0, 65500
#define RELAY_OFF 65500, 0
//#define RELAY_MODE(...) valve[IDX_RELAY].setTime(__VA_ARGS__)
#else
//#define INFOLED_STATUS(...)
//#define RELAY_MODE(...)
#endif  // SMART_RELAY
