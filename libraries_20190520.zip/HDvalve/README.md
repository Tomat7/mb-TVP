# HDvalve
Simple valve start-stop control library

Used to control flow (speed of collection) of "product" on special devices. :-)

P.S. Sorry, no example yet. :-(
