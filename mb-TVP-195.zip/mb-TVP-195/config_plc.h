#pragma once
// ниже "шаблоны" модулей - поправить под свои нужды
// только один датчик давления может быть в скетче! иначе, надо перелопатить нумерацию регистров Модбаса
#if PLC_ID == 32          // AVR, BMP280, 192.168.1.32
#define USE_OLED
#define OLED_SH1106
#define DSPINS { 3, 4, 6 }  // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 7, 8 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define PRESSURE_BMP        // скомпилировать с поддержкой датчика атмосферного давления BMP280
#define BMP280_ADDRESS 0x76 // адрес датчика BMP280 - необходимо найти с помощью i2c_scanner.ino
#define ETHERNET_ENC28J60   // с регулятором мощности шилд enc28j60 использовать не рекомендуется
#ifndef __AVR__
#error "Wrong module defined. Use Arduino Nano or change PLC_ID."
#endif  // !__AVR__
#endif  // PLC_ID == 32
// ===
#if PLC_ID == 33          // AVR, LCD test,  192.168.1.33
#define USE_OLED
//#define USE_LCD
#define OLED_SH1106
#define DSPINS { 3, 4, 5 }  // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 7, 8 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
//#define PRESSURE_BMP        // скомпилировать с поддержкой датчика атмосферного давления BMP280
//#define BMP280_ADDRESS 0x76 // адрес датчика BMP280 - необходимо найти с помощью i2c_scanner.ino
#define PRESSURE_MPX        // скомпилировать с поддержкой датчика давления в кубе MPX5010dp
#define MPX5010_PIN A1      // PIN на который подключен датчик MPX5010dp
#define ETHERNET_WIZ5100    // с регулятором мощности шилд enc28j60 использовать не рекомендуется
#ifndef __AVR__
#error "Wrong module defined. Use Arduino Nano or change PLC_ID."
#endif // !__AVR__
#endif  // PLC_ID == 33
// ===
#if PLC_ID == 35          // AVR, MPX5010, 192.168.1.35
#define USE_OLED
#define DSPINS { 3, 4, 5 }  // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 8, 9 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define PRESSURE_MPX        // скомпилировать с поддержкой датчика давления в кубе MPX5010dp
#define MPX5010_PIN A1      // PIN на который подключен датчик MPX5010dp
#define ETHERNET_ENC28J60   // с регулятором мощности шилд enc28j60 использовать не рекомендуется
#ifndef __AVR__
#error "Wrong module defined. Use Arduino Nano or change PLC_ID."
#endif
#endif  // PLC_ID == 35
// ===
#if PLC_ID == 40          // ESP32, 192.168.1.40
#define OTA_HOSTNAME "PLC-40 TVP_v" VERSION_CODE
#define SMART_RELAY
#define BUTTON_MODE 12
#define USE_OLED
#define IDX_INFOLED 0
#define IDX_RELAY 1
//#define OLED_SH1106
#define DSPINS { 32, 33, 25 }  // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 12, 13, 18 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define PRESSURE_BMP        // скомпилировать с поддержкой датчика атмосферного давления BMP280
#define BMP280_ADDRESS 0x76 // адрес датчика BMP280 - необходимо найти с помощью i2c_scanner.ino
//#define PRESSURE_MPX        // скомпилировать с поддержкой датчика давления в кубе MPX5010dp
//#define MPX5010_PIN 34      // PIN на который подключен датчик MPX5010dp
#ifndef ESP32
#error Wrong module defined. Use ESP32 or change PLC_ID.
#endif
#endif  // PLC_ID == 40 // ESP32
// ===
#if PLC_ID == 41          // ESP8266, 192.168.1.41, Sonoff TH16 SmartRelay
#define OTA_HOSTNAME "PLC-41 (Bamboo) TH16_v" VERSION_CODE
#define SMART_RELAY
#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 41
// ===
#if PLC_ID == 42            // ESP8266, 192.168.1.42, Sonoff TH16 SmartRelay
#define OTA_HOSTNAME "PLC-42 (Garage) TH16_v" VERSION_CODE
#define SMART_RELAY
#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 42
// ===
#if PLC_ID == 43          // ESP8266, 192.168.1.43, Sonoff TH16 SmartRelay Gate controller 
#define OTA_HOSTNAME "PLC-43 TEST TH16_v" VERSION_CODE
#define GATE_RELAY
#define SMART_RELAY
#define USE_WEBSERVER
#define DHTPIN 14               // модуль без DS18B20
//#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#define DS_CONVTIME 1000     // как часто опрашивать DS18B20 (миллисекунды)
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 43
// ===
/* 44 */
// ===
#if PLC_ID == 45          // ESP8266, 192.168.1.45, Sonoff S20 SmartSocket (умная розетка)
#define OTA_HOSTNAME "PLC-45 (Duralight) S20_v" VERSION_CODE
#define SMART_RELAY
#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 45
// ===
#if PLC_ID == 47          // ESP8266, 192.168.1.47, Sonoff S20 SmartSocket (умная розетка)
#define OTA_HOSTNAME "PLC-47 S20_v" VERSION_CODE " (Cooling)"
#define WIFI_CHANNEL 1
#define SMART_RELAY
#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 47
// ===
#if PLC_ID == 48          // ESP8266, 192.168.1.48, Sonoff S20 SmartSocket (умная розетка)
#define OTA_HOSTNAME "PLC-48 S20_v" VERSION_CODE
#define SMART_RELAY
#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif // !ESP8266
#endif  // PLC_ID == 48
// ===
#if PLC_ID == 49          // ESP8266, 192.168.1.49, Sonoff TH16 SmartRelay Gate controller 
#define OTA_HOSTNAME "PLC-49 TH16_v" VERSION_CODE " (Gate)"
#define GATE_RELAY
#define SMART_RELAY
#define USE_WEBSERVER
#define DHTPIN 14               // модуль без DS18B20
//#define DSPINS { 14 }         // на эти пины подключается по **одному** датчику DS18B20
#define VALVEPINS { 13, 12 }  // на эти пины подключаются обвязка клапанов (оптопара/транзистор, SSR и тд.)
#define IDX_INFOLED 0
#define IDX_RELAY 1
#define BUTTON_MODE 0
#define DS_CONVTIME 1000     // как часто опрашивать DS18B20 (миллисекунды)
#ifndef ESP8266
#error "Wrong module defined. Use ESP8266 or change PLC_ID."
#endif
#endif  // PLC_ID == 49
// ===
