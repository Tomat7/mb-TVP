
#include "Arduino.h"
#include "HDvalve.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "display.h"
#include "functions.h"
#include "macros.h"
Valve valve[] = {VALVEPINS};
const int nValve = sizeof(valve) / sizeof(Valve); // считаем количество клапанов

void initValve()
{
#ifdef __AVR__
  LD_printString_6x8("VALVE on pin: ", LCDX1, 7);
#else
  LD_printString_6x8("VALVE: ", LCDX1, 7);
#endif

  for (int i = 0; i < nValve; i++) {
    byte hrOpen = hrOPEN + i * 3; // сдвиг если клапанов больше одного
    byte hrClose = hrCLOSE + i * 3;
    byte hrClicks = hrCLICKS + i * 3;
    valve[i].init();
    mb.addHreg(hrOpen); // Длительность нахождения клапана в ОТКРЫТОМ состоянии
    mb.addHreg(hrClose); // Длительность нахождения клапана в ЗАКРЫТОМ состоянии
    mb.addHreg(
        hrClicks); // количество кликов с начала работы (для расчета объема)
    int pins[] = {VALVEPINS};
    LD_printNumber((long)pins[i]);
    if (i < (nValve - 1))
      LD_printChar_6x8(", ");
#ifdef SERIAL_DEBUG
    mb.addHreg(hrVALVEDEBUG + i); // DEBUG !! длительность крайнего открытия
#endif
  }
}

void updateValve(int i)
{
  byte hrOpen = hrOPEN + i * 3; // сдвиг если клапанов больше одного
  byte hrClose = hrCLOSE + i * 3;
  byte hrClicks = hrCLICKS + i * 3;

  if (mbMasterOK) {
    if (mb.Hreg(hrClicks) == 65535)
      valve[i].Clicks = 0;
    else if (mb.Hreg(hrClicks) > valve[i].Clicks)
      valve[i].Clicks = mb.Hreg(hrClicks);
    mb.Hreg(hrClicks, valve[i].Clicks); // сохраняем сколько всего накликали
  }
  else {
    mb.Hreg(hrOpen, 0); // а если Мастера нет - прекращаем клацать клапаном
    mb.Hreg(hrClose, 65535);
  }

  valve[i].setTime(
      mb.Hreg(hrClose),
      mb.Hreg(hrOpen)); // задаем длительность в открытом и закрытом состоянии
  dtostrf(mb.Hreg(hrOpen), 4, 0, cbuf);
  LD_printString_6x8(
      cbuf, LCDX2,
      i); // показываем на дисплее длительность в отрытом состоянии
  dtostrf(mb.Hreg(hrClose), 5, 0, cbuf);
  LD_printString_6x8(
      cbuf, LCDX2 + 32,
      i); // показываем на дисплее длительность в закрытом состоянии

#ifdef SERIAL_INFO
  String vInfo = "VALVE " + String(i, DEC) + ": On " +
                 String(mb.Hreg(hrOpen), DEC) + ": Off " +
                 String(mb.Hreg(hrClose), DEC) +
                 " ms | clicks: " + String(valve[i].Clicks, DEC);
  Serial.println(vInfo);
#endif
#ifdef SERIAL_DEBUG
  vInfo = vInfo + "lastOn " + String(valve[i].lastON, DEC) + " ms | Off " +
          String(valve[i].lastOFF, DEC) + " ms";
  Serial.println(vInfo);
  mb.Hreg(hrVALVEDEBUG + i, valve[i].lastON);
#endif
}

bool isNoFlowNow()
{
#ifdef SMART_RELAY
  return true;
#else
  return (!valve[0].Flow && !valve[1].Flow);
#endif
}
