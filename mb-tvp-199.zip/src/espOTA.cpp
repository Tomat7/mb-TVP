
#include "Arduino.h"
#include "config.h" // описание переменных, констант
#include "config_net.h" // конфигурация сети
#include "config_plc.h" // конфигурация контроллеров
#include "declarations.h"
#include "display.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"

void checkOTA()
{
#ifdef OTA_HOSTNAME
  ArduinoOTA.handle();
#endif // OTA_HOSTNAME
}

void initOTA()
{
#ifdef OTA_HOSTNAME
  ArduinoOTA.setHostname(OTA_HOSTNAME);
  ArduinoOTA.setPassword(WIFI_PASS);
  ArduinoOTA.setPort(OTA_PORT);

  ArduinoOTA.onStart([]() // switch off all the PWMs during upgrade
                     {
                       String type;
                       if (ArduinoOTA.getCommand() == U_FLASH) {
                         type = "sketch";
                       }
                       else { // U_SPIFFS
                         type = "filesystem";
                       }
                       // NOTE: if updating SPIFFS this would be the place to
                       // unmount SPIFFS using SPIFFS.end()
                       Serial.println("OTA update starting " + type);
                       // modbusON = false;
                       display_Clear();
                       display_String("OTA update", LCDX1, 0);
                       // analogWrite(led_pin, 0);
                     });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
    display_String("%% ", 24, 3);
    LD_printNumber((long)(progress / (total / 100)));
  });

  ArduinoOTA.onEnd([]() // do a fancy thing with our board led at end
                   {
                     Serial.println("\n OTA update finished!");
                     display_String("OTA OK!", LCDX1, 6);
                     delay(3000);
                     // modbusON = true;
                   });

  ArduinoOTA.onError([](ota_error_t error) {
    String OTAErrorInfo;
    Serial.printf("OTA Error[%u]: ", error);
    display_String("OTA error", LCDX1, 3);

    if (error == OTA_AUTH_ERROR)
      OTAErrorInfo = "OTA Auth Failed";
    else if (error == OTA_BEGIN_ERROR)
      OTAErrorInfo = "OTA Begin Failed";
    else if (error == OTA_CONNECT_ERROR)
      OTAErrorInfo = "OTA Connect Failed";
    else if (error == OTA_RECEIVE_ERROR)
      OTAErrorInfo = "OTA Receive Failed";
    else if (error == OTA_END_ERROR)
      OTAErrorInfo = "OTA End Failed";

    Serial.println(OTAErrorInfo);
    LD_printString_6x8(OTAErrorInfo.c_str(), LCDX1, 5);
    delay(3000);
    Serial.println("rebooting...");
    LD_printString_6x8("reboot...", LCDX1, 6);
    delay(1000);
    (void)error;
    ESP.restart();
  });

  /* setup the OTA server */
  ArduinoOTA.begin();
  Serial.println("OTA Ready");
#endif
}
