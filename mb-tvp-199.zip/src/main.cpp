
/*
  Base/common configuration in "config.h"
  PLC configuration in "config_plc.h"
*/

#include "Arduino.h"
#include "config.h" // описание переменных, констант
#include "config_net.h" // конфигурация сети
#include "config_plc.h" // конфигурация контроллеров
#include "declarations.h"
#include "display.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"
// *** обязательно заглянуть и поправить по необходимости! ***

void setup()
{
  Serial.begin(SERIALSPEED);
  setupKeys();
  display_Init();
  display_Clear();

  String strVersion = SKETCHFILE;
  String strVer = strVersion.substring(1 + strVersion.lastIndexOf('\\'));
  char chVer[16];
  strVer.toCharArray(chVer, 16);
  LD_printString_6x8(chVer, LCDX1, 0);

  delay(300);
  CFG_PRINT(strVersion);
  CFG_PRINTLN(F(SKETCHTIME));

  printFreeRam();
  setupNetMB();

  mb.addHreg(hrSECONDS); // Like "alive" flag counter for future (for HeartBeat)
  initDS();
  initValve();
  initPressure();

  msReinit = millis();
  printFreeRam();
  delay_ms(3000);
  display_Clear();
  web_Setup();
}

void loop()
{
  //    for (int i = 0; i < nSensor; i++) ds18b20[i].check(); // зачем так
  //    часто?
  for (int i = 0; i < nValve; i++)
    valve[i].control();

  mb.task();

  if (needUpdate(1) && (isNoFlowNow() || needUpdate(2))) {
    display_String("MB___", LCDX2, 6);

    for (int i = 0; i < nSensor; i++)
      updateDS(i);

    for (int i = 0; i < nValve; i++)
      updateSwitch(i);

    updatePressure();
    msReinit = millis();
    checkMBmaster(); // Проверяем "живость" Modbus мастера
  }

  checkKeys();
  checkOTA();
  checkWeb();
}
