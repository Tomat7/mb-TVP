#pragma once

#include "Arduino.h"
#include "declarations.h"

void checkMBmaster();
void updateSwitch(int i);
void delay_ms(uint32_t msWait);
void printFreeRam();
bool needUpdate(int m);

void setupNetMB();
void serialMAC(uint8_t *mac);
void displayMAC(uint8_t *mac);
void initETH(uint8_t *mac);
void serialIP();
void displayIP();

void initDS();
void updateDS(int i);

void initPressure();
void updatePressure();
void updBMP();
void updMPX();
void updDHT();

void initValve();
void updateValve(int i);
bool isNoFlowNow();

void setupKeys();
void checkKeys();
void checkShortPress();
void checkButton();

void setDelay(uint16_t minutesON);
void checkTicks();
void updateRelay();
void setLedStatus(uint16_t msOff, uint16_t msOn);
void setRelayMode(uint16_t msOff, uint16_t msOn);

extern unsigned long msReinit;
extern uint16_t msGet, msLcd;
extern uint16_t msTimeout;
extern const char degC;
extern char cbuf[];
extern bool mbMasterOK;
extern bool modbusON;
extern bool relayON;
extern int16_t tickToRelayOff;
// float t0 = 1;
// int h0 = 2;
