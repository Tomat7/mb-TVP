#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "declarations.h"
#include "display.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"

#ifdef SMART_RELAY
#include <ReadDigKey.h>
ReadDigKey key;
#endif // SMART_RELAY

void setupKeys()
{
#ifdef SMART_RELAY
  key.add_key(BUTTON_MODE);
  mb.addHreg(hrDSCONVTIME, tickToRelayOff);
#endif // SMART_RELAY
}

void checkKeys()
{
#ifdef SMART_RELAY
  key.readkey(); // Чтение клавиатуры
#endif           // SMART_RELAY
}

void checkShortPress()
{
#ifdef SMART_RELAY
  if (key.shot_press()) {
    delay(2000);
    confWiFi(false);
  }
#endif // SMART_RELAY
}

void checkButton()
{
#ifdef SMART_RELAY
  if (key.long_press())
    modbusON = !modbusON;

#ifdef GATE_RELAY
  if (key.shot_press()) {
    //    relayON = !relayON;
    if (!tickToRelayOff)
      setDelay(RELAY_POWERON_MINS);
    else
      tickToRelayOff = 0;
    PRINTLN("relayON");
  }
#else
  if (!modbusON && key.shot_press())
    relayON = !relayON;
  if (modbusON)
    relayON = false;
#endif // GATE_RELAY
#endif // SMART_RELAY
}
