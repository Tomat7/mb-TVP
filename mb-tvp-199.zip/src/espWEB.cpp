#include "Arduino.h"
#include "config.h" // описание переменных, констант
#include "config_net.h" // конфигурация сети
#include "config_plc.h" // конфигурация контроллеров
#include "declarations.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"

#ifdef USE_WEBSERVER
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>
#include <WiFiClient.h>
ESP8266WebServer httpd(80);
#else
#pragma message ("WEB not configured! Nothing to compile. ")
#endif // USE_WEBSERVER

#ifdef USE_NTP
#include <NTPClient.h>
#include <WiFiUdp.h>
WiFiUDP ntpUDP;
NTPClient NTP(ntpUDP, "192.168.1.254", NTP_TIMEZONE_OFFSET, NTP_UPDATE_PERIOD);
unsigned long msNTPupdate = 0;
#endif // USE_NTP

void checkWeb()
{
#ifdef USE_WEBSERVER
  httpd.handleClient();
#endif // USE_WEBSERVER
#ifdef USE_NTP
  if ((millis() - msNTPupdate) > NTP_UPDATE_PERIOD) {
    NTP.update();
    msNTPupdate = millis();
  }
#endif // USE_NTP
}

void web_Setup()
{
#ifdef USE_WEBSERVER
  if (MDNS.begin(OTA_HOSTNAME))
    CFG_PRINT("+ MDNS responder started.");
  httpd.on("/", web_handleRoot);
  httpd.on("/on", web_handleON);
  httpd.on("/off", web_handleOFF);
  httpd.on("/reset", web_handleRST);
  // httpd.on("/inline", [] () { httpd.send(200, "text/plain", "this works as
  // well"); });
  httpd.onNotFound(web_handleNotFound);
  httpd.begin();
#endif // USE_WEBSERVER

#ifdef USE_NTP
  NTP.begin();
#endif // USE_NTP
}

#ifdef USE_WEBSERVER

void web_Check() { httpd.handleClient(); }

void web_handleRoot() { httpd.send(200, "text/html", web_SendHTML(0)); }

void web_handleON()
{
  if ((httpd.args() == 1) && (httpd.argName(0) == "p")) {
    String sDelayWeb = httpd.arg(0);
    setDelay(sDelayWeb.toInt());
  }
  httpd.send(200, "text/html", web_SendHTML(0));
}

void web_handleOFF()
{
  //	Pweb = 0;
  //	setPower(Pweb);
  setDelay(0);
  httpd.send(200, "text/html", web_SendHTML(0));
}

void web_handleRST()
{
  //	Pweb = 0;
  //	setPower(Pweb);
  //	TEH.stop();
  //	delay(20);
  ESP.restart();
  httpd.send(200, "text/html", web_SendHTML(0));
}

void web_handleNotFound()
{
  // String UriPath = httpd.uri();
  String message = "File Not Found\n\n";
  message += "URI: ";
  message += httpd.uri();
  // message += UriPath.substring(1, 3);
  // message += UriPath.substring(3);
  message += "\nMethod: ";
  message += (httpd.method() == HTTP_GET) ? "GET" : "POST";
  message += "\nArguments: ";
  message += httpd.args();
  message += "\n";

  for (uint8_t i = 0; i < httpd.args(); i++) {
    message += " " + httpd.argName(i) + ": " + httpd.arg(i) + "\n";
  }

  httpd.send(404, "text/plain", message);
}

String web_SendHTML(uint16_t Ptmp)
{
  char HtmlStr[50];
  // char CmpDate[10];
  int sec = millis() / 1000;
  int min = sec / 60;
  int hr = min / 60;
  int days = hr / 24;

#ifdef USE_NTP
  time_t epochTime = NTP.getEpochTime();
  struct tm *ptm = gmtime((time_t *)&epochTime);
  // tm *ptm = gmtime(&epochTime);
  int HH = ptm->tm_hour;
  int MM = ptm->tm_min;
  int SS = ptm->tm_sec;
  int dd = ptm->tm_mday;
  int mm = ptm->tm_mon + 1;
  int yyyy = ptm->tm_year + 1900;
#endif // USE_NTP

  String ptr = "<!DOCTYPE html> <html>\n";
  ptr += "<head><meta name=\"viewport\" content=\"width=device-width, "
         "initial-scale=1.0, user-scalable=no\">\n";
  ptr += "<meta http-equiv=\"refresh\" content=\"5;url=/\">\n";
  ptr += "<title>Power Controller</title>\n";
  ptr += "<style>html { font-family: Helvetica; display: inline-block; "
         "margin: "
         "0px auto; text-align: center;}\n";
  ptr += "body{margin-top: 50px;} h1 {color: #444444;margin: 50px auto 30px;} "
         "h3 "
         "{color: #444444;margin-bottom: 20px;}\n";
  ptr += ".button {display: block;width: 80px;background-color: "
         "#3498db;border: "
         "none;color: white;padding: 13px 30px;text-decoration: "
         "none;font-size: "
         "25px;margin: 0px auto 35px;cursor: pointer;border-radius: 4px;}\n";
  ptr += ".button-on {background-color: #3366CC;}\n";        // #3498db #336699
  ptr += ".button-on:active {background-color: #003399;}\n"; // #2980b9
  ptr += ".button-off {background-color: #FF0033;}\n";
  ptr += ".button-off:active {background-color: #CC0000;}\n";
  ptr += "p {font-size: 14px;color: #888;margin-bottom: 10px;}\n";
  ptr += "</style>\n";
  ptr += "</head>\n";
  ptr += "<body>\n";
  ptr += "<h1>Gate Power Controller</h1>";

  snprintf(HtmlStr, 50, "<h3>TicksToOFF: %4d</h3>", tickToRelayOff);
  ptr += HtmlStr;
#ifdef DSPINS
  snprintf(HtmlStr, 50, "<h3>Temp: %.2f</h3>", ds18b20[0].Temp);
  ptr += HtmlStr;
#elif defined(DHTPIN)
  const char gradusC = 176;
  snprintf(HtmlStr, 50, "<h3>Temp: %.1f%c  Humidity: %4d%%</h3>",
           (float)mb.Hreg(hrTEMP) / 100, gradusC, mb.Hreg(hrPRESSURE));
  ptr += HtmlStr;
#endif

#ifdef USE_NTP
  snprintf(HtmlStr, 50, "<h3>%4d-%02d-%02d %02d:%02d:%02d</h3>", yyyy, mm, dd,
           HH, MM, SS);
  ptr += HtmlStr;
#endif // USE_NTP

  snprintf(HtmlStr, 50, "<h3>Up: %2d days, %2d:%02d:%02d</h3>\n", days, hr % 24,
           min % 60, sec % 60);
  ptr += HtmlStr;

  ptr += "<a class=\"button button-off\" href=\"/off\">STOP</a>\n";
  // ptr += "<p><a class=\"button button-on\" href=\"/on?p=100\">100</a>\n";

  String PButton = "<p><a class=\"button button-on\" href=\"/on?p=";

#define WEB_POWER1 5
  // #define WEB_POWER2 10

#ifdef WEB_POWER1
  snprintf(HtmlStr, 50, "%d\">%d</a>", WEB_POWER1, WEB_POWER1);
  ptr += PButton + HtmlStr;
#endif // WEB_POWER1
#ifdef WEB_POWER2
  snprintf(HtmlStr, 50, "%d\">%d</a>", WEB_POWER2, WEB_POWER2);
  ptr += PButton + HtmlStr;
#endif // WEB_POWER2
#ifdef WEB_POWER3
  snprintf(HtmlStr, 50, "%d\">%d</a>", WEB_POWER3, WEB_POWER3);
  ptr += PButton + HtmlStr;
#endif // WEB_POWER3

  /* ptr += "<p><a class=\"button button-on\" href=\"/on?p=1000\">1000</a>\n";
     ptr += "<p><a class=\"button button-on\" href=\"/on?p=1500\">1500</a>\n";
     ptr += "<p><a class=\"button button-on\" href=\"/on?p=1700\">1700</a>\n";
     ptr += "<p><a class=\"button button-on\" href=\"/on?p=3000\">3000</a>\n";
  */

  snprintf(HtmlStr, 50, "<p>Version: %s</p>\n", VERSION_CODE);
  ptr += HtmlStr;

  snprintf(HtmlStr, 50, "<p>Compiled on %s (C) Tomat7.</p>\n", __DATE__);
  ptr += HtmlStr;

  snprintf(HtmlStr, 50, "<p>Delay: %4d </p>\n", (millis() - msReinit));
  ptr += HtmlStr;
  /*
    String ota_string = WIFI_PASS + String(PLC_ID);
    snprintf(HtmlStr, 50, "<p>OTA_String: %s </p>\n", ota_string.c_str());
    ptr += HtmlStr;

    const char *ota_chars = ota_string.c_str();
    snprintf(HtmlStr, 50, "<p>OTA_Chars: %s </p>\n", ota_chars);
    ptr += HtmlStr;
  */
  snprintf(HtmlStr, 50, "<p>OTA_StrNow: %s </p>\n",
           String(WIFI_PASS + String(PLC_ID)).c_str());
  ptr += HtmlStr;

  if (mbMasterOK)
    snprintf(HtmlStr, 50, "<p>Modbus OK. ");
  else
    snprintf(HtmlStr, 50, "<p>Modbus OFF. ");
  ptr += HtmlStr;

  if (modbusON)
    snprintf(HtmlStr, 50, " Local mode.</p>\n");
  else
    snprintf(HtmlStr, 50, "</p>\n");
  ptr += HtmlStr;

  ptr += "</body>\n";
  ptr += "</html>\n";
  return ptr;
}

void DateToBuff(char const *date, char *buff)
{
  int month, day, year;
  static const char month_names[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
  sscanf(date, "%s %d %d", buff, &day, &year);
  month = (strstr(month_names, buff) - month_names) / 3 + 1;
  snprintf(buff, 10, "%d%02d%02d", year, month, day);
}
#endif // USE_WEBSERVER
