#pragma once

#include "Arduino.h"

void display_Init();
void display_Clear();
void display_String(String str0);
void display_String(String str0, int X, int Y);

// ===
#ifdef USE_OLED
#include "ASOLED.h"
extern ASOLED LD;
#if defined(OLED_SH1106)
#define LCDX1 0  // смещение 1-го "столбца" на экране
#define LCDX2 65 // смещение 2-го "столбца" на экране
#else
#define LCDX1 1  // смещение 1-го "столбца" на экране
#define LCDX2 67 // смещение 2-го "столбца" на экране
#endif           // OLED_SH1106
#endif           // USE_OLED

// ===
#ifdef USE_LCD
#include "LiquidCrystal_I2C.h"
extern LiquidCrystal_I2C
    LCD;        // set the LCD address to 0x27 for a 16 chars and 2 line display
#define LCDX1 0 // смещение 1-го "столбца" на экране
#define LCDX2 10 // смещение 2-го "столбца" на экране
#endif           // USE_LCD

#ifndef LCDX1
#define LCDX1 0  // смещение 1-го "столбца" на экране
#define LCDX2 10 // смещение 2-го "столбца" на экране
#endif
