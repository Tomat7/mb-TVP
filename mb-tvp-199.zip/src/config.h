#pragma once

#define VERSION_CODE "199"
#define _ID 46

/*  PLC_ID - "адрес" устройства, от него формируются MAC и IP адреса и
   выбираются шаблоны модулей 31 - AVR POWER regulator, 32 - AVR TVP (BMP280),
   35 - AVR TVP (MPX5010), 36-39 - reserved POWER regulator, AVR or ESP32 (other
   sketches) 40 - ESP32 test, 41-44 - ESP8266 SonOff TH, 45-48 - ESP8266 SonOff
   SD, 49 - ESP32 GATE controller
*/

#define STRING2(x) #x
#define STRING(x) STRING2(x)

#ifdef PLC_ID
#define PLC_ID_MSG "Defined in platformio.ini file! PLC_ID = "
#else
#define PLC_ID_MSG "Configured in config.h! PLC_ID = "
#define PLC_ID _ID
#endif

#ifdef PLATFORMIO // Platformio
#define P_CODE "p" STRING(PLATFORMIO)
#else // Arduino
#define P_CODE "a"
#endif

#define SKETCHFILE __FILE__ " "
#define SKETCHTIME __DATE__ " " __TIME__

// как долго можно работать/кликать_клапаном без мастера Модбаса (секунды)
#define MB_TIMEOUT 70 
// скорость в последовательном порту
#define SERIALSPEED 115200
// если нужно выдать только конфигурацию в Serial
#define SERIAL_CONFIG
// если нужно постоянно выдавать информацию в Serial
//#define SERIAL_INFO
// доп. информация в Serial и в регистры Модбаса ** нужно поправить библиотеки! **
//#define SERIAL_DEBUG        

#ifndef DS_CONVTIME
#define DS_CONVTIME 800 // как часто опрашивать DS18B20 (миллисекунды)
#endif

//#include "Modbus.h"
// ModbusIP mb;
