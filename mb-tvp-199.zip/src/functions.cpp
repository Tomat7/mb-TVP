
#include "functions.h"

#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "display.h"
#include "esp.h"
#include "macros.h"

bool mbMasterOK;
bool modbusON;

unsigned long msReinit;
uint16_t msGet, msLcd;
uint16_t msTimeout = DS_CONVTIME;

uint16_t ui16;
uint32_t ui32;
uint64_t ui64;


void checkMBmaster()
{
  checkWiFi();
  // если мастер онлайн - он должен записывать 0 в регистр hrSECONDS
  // это будет признаком "живости" Мастера Modbus'а для модуля
  // и наоборот: не 0 в SECONDS - признак "живости" модуля для Мастера
  // хотя Мастеру логичнее отслеживать "живость" по GetQuality
  uint16_t secUptime = (uint16_t)(msReinit / 1000);

  if (mb.Hreg(hrSECONDS) == 0)
    mb.Hreg(hrSECONDS, secUptime);

  if ((secUptime - mb.Hreg(hrSECONDS)) < MB_TIMEOUT) {
    display_String("MB_OK", LCDX2, 6);
    mbMasterOK = true;
  }
  else // если мастера нет больше MB_TIMEOUT секунд - пишем на экране и в порт
  {
    display_String("  OFF", LCDX2, 6);
#ifdef SERIAL_INFO
    PRINT("Master OFFline ");
    PRINTLN(mb.Hreg(hrSECONDS));
#endif
    mbMasterOK = false;
  }
}

void updateSwitch(int i)
{
#ifdef SMART_RELAY
  if (!i) {
    checkButton();
    checkTicks();
    updateRelay();
  }
#else
  updateValve(i);
#endif
}

void delay_ms(uint32_t msWait)
{
#ifdef IDX_INFOLED
  uint32_t msBegin = millis();
  while ((millis() - msBegin) < msWait) {
    valve[IDX_INFOLED].control();
    delay(20);
    checkKeys();
  }
#else
  delay(msWait);
#endif // IDX_INFOLED
}

void printFreeRam()
{
#ifdef SERIAL_CONFIG
#if defined(__AVR__)
  Serial.print(F("Free RAM: "));
  extern int __heap_start, *__brkval;
  int v, r;
  r = (int)&v - (__brkval == 0 ? (int)&__heap_start : (int)__brkval);
  Serial.println(r);
#elif defined(ESP32) || defined(ESP8266)
  Serial.print(F("Free RAM: "));
  Serial.println(ESP.getFreeSketchSpace());
#endif
#endif // SERIAL_CONFIG
}

bool needUpdate(int m) { return ((millis() - msReinit) > (uint32_t)(msTimeout * m)); }

/*
  int *intFloat(float f, byte d)
  {
  static int intF[2];
  intF[0] = (int)f;                          // compute the integer part of the
  float intF[1] = (int)((f - (float)intF[0]) * d * 10); // compute 1 decimal
  places (and convert it to int) return intF;
  }
*/
void (*resetFunc)(void) = 0; // Перезагрузка Ардуины
