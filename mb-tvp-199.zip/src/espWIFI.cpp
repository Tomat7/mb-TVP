#include "Arduino.h"
#include "config.h" // описание переменных, констант
#include "config_net.h" // конфигурация сети
#include "config_plc.h" // конфигурация контроллеров
#include "declarations.h"
#include "display.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"

#if defined(ESP32) || defined(ESP8266)

IPAddress local_IP(ETHERNET_IP);
IPAddress gateway(IP_NETWORK + 254);
IPAddress subnet(255, 255, 255, 0);

const char *OTA_pass = String(WIFI_PASS + String(PLC_ID)).c_str();
bool wifiConnectOK = false;
bool wifiStrong = true;
int wifiErrors = 0;

#if WIFI_CHANNEL == 1
byte bssid[] = {0x18, 0xE8, 0x29, 0x09, 0xA1, 0xE2};
#endif // WIFI_CHANNEL == 1
#endif

// static int wifiErrors = 0;
// static bool wifiStrong = true;

void checkWiFi()
{
#if defined(ESP32) || defined(ESP8266)

  if (WiFi.status() == WL_CONNECTED) {
    wifiConnectOK = true;
    wifiErrors = 0;
  }
  else {
    PRINT(".");
    wifiConnectOK = false;
    wifiErrors++;
  }

  if ((wifiErrors > MB_TIMEOUT) && wifiStrong)
    ESP.restart();

#endif
}

#if defined(ESP32) || defined(ESP8266)
void initWiFi()
{
  wifiConnectOK = false;
  mbMasterOK = false;
  CFG_PRINT("Connecting to ");
  CFG_PRINTLN(WIFI_NAME);

  confWiFi(true);

  CFG_PRINT("MAC: ");
  CFG_PRINTLN(WiFi.macAddress());

  static char macbuff[17] = {"                "};
  String macStr = WiFi.macAddress();
  macStr.toCharArray(macbuff, 18);
  LD_printString_6x8("MAC:", LCDX1, 1);
  LD_printString_6x8(macbuff, LCDX1 + 25, 1);
  setLedStatus(MODE_SEARCH_WIFI);

  while (!wifiConnectOK) {
    checkWiFi();
    delay_ms(100);
    checkShortPress();
  }

  initOTA();
  mb.slave();

  setLedStatus(MODE_MODBUS_WAIT);
  modbusON = true;
}

void confWiFi(bool withBSSID)
{
  WiFi.disconnect(true);
  WiFi.mode(WIFI_STA);
  if (!WiFi.config(local_IP, gateway, subnet))
    CFG_PRINTLN("ESP32 WiFi failed to configure");

#ifdef WIFI_CHANNEL
  if (withBSSID) {
    WiFi.begin(WIFI_NAME, WIFI_PASS, WIFI_CHANNEL, bssid, true);
    wifiStrong = true;
  }
  else {
    WiFi.begin(WIFI_NAME, WIFI_PASS);
    wifiStrong = false;
  }
#else
  WiFi.begin(WIFI_NAME, WIFI_PASS);
#endif // WIFI_CHANNEL
}

void esp_serialIP()
{
  Serial.println("");
  Serial.println("WiFi connected!");
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("Mask: ");
  Serial.println(WiFi.subnetMask());
  Serial.print("Gateway: ");
  Serial.println(WiFi.gatewayIP());
  return;
}

void esp_diplayIP()
{
  static char macbuff[17] = {"                "};
  sprintf(macbuff, "%i.%i.%i.%i", WiFi.localIP()[0], WiFi.localIP()[1],
          WiFi.localIP()[2], WiFi.localIP()[3]);
  LD_printString_6x8("IP:", LCDX1, 3);
  LD_printString_6x8(macbuff, LCDX1 + 22, 3);
}

#endif // ESP32/ESP8266
