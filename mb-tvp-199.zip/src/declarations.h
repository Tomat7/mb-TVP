#pragma once

#include "config.h"
#include "config_plc.h"
//#include "config_net.h"

#ifdef DSPINS
#include "DStemp.h"
extern DSThermometer ds18b20[];
extern const int nSensor;
// = sizeof(ds18b20) / sizeof(DSThermometer);  // считаем количество DS'ок
#elif defined(DHTPIN)
#include "dhtnew.h"
extern DHTNEW dht;
extern const int nSensor;
#endif // DSPINS

#ifdef VALVEPINS
#include "HDvalve.h"
extern Valve valve[];
extern const int nValve; // считаем количество клапанов
#endif                   // VALVEPINS

#ifdef PRESSURE_BMP
#include "BMP280x.h"
extern BMP280x bmp280;
#endif

#ifdef PRESSURE_MPX
#include "ADCmulti.h"
extern ADCmulti mpx5010dp;
// int Pins[] = { MPX5010_PIN };
// int Vals[] = { &mpxRAW };
#endif

#ifdef SMART_RELAY
#define RELAY_POWERON_MINS 5 // in minutes
#include <ReadDigKey.h>
extern ReadDigKey key;
#endif // SMART_RELAY

// ===
#define hrSECONDS 0 // регистр-счетчик секунд uptime'а
#define hrTEMP hrSECONDS + 1 // первый регистр с температурой
#define hrPRESSURE hrTEMP + nSensor // регистр давления
#define hrOPEN hrPRESSURE + 1 // первый регистр с данными для/от клапанов
#define hrCLOSE hrOPEN + 1 // "базовая" скорость - объем собранный за 1000 кликов
#define hrCLICKS hrOPEN + 2 // количество кликов с момента включения
// === DEBUG!! (можно менять удаленно)
#define hrDSCONVTIME hrOPEN + nValve * 3 // таймаут на преобразование DS
#define hrDSDEBUG hrDSCONVTIME + 1 // будем хранить время преобразования каждой DS'ки
#define hrVALVEDEBUG hrDSDEBUG + nSensor // будем хранить длительность открытия каждого клапана
// ===
