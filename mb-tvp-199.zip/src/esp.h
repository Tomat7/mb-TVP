#pragma once

#include "config.h" // описание переменных, констант
#include "config_net.h" // конфигурация сети
#include "config_plc.h" // конфигурация контроллеров

void initWiFi();
void confWiFi(bool withBSSID);
void checkWiFi();

void initOTA();
void checkOTA();

void checkWeb();
void checkWeb();
void web_Setup();

void esp_serialIP();
void esp_diplayIP();

void web_handleRoot();
void web_handleON();
void web_handleOFF();
void web_handleRST();
void web_handleNotFound();
String web_SendHTML(uint16_t Ptmp);
void DateToBuff(char const *date, char *buff);
