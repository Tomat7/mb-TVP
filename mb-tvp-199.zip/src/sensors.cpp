
#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "display.h"
#include "functions.h"
#include "macros.h"

#ifdef DSPINS
#include "DStemp.h"
DSThermometer ds18b20[] = {DSPINS};
const int nSensor = sizeof(ds18b20) / sizeof(DSThermometer); // количество DS'ок
#elif defined(DHTPIN)
#include "dhtnew.h"
DHTNEW dht(DHTPIN);
const int nSensor = 1;
#endif

void initDS()
{
#ifdef DSPINS
#ifdef __AVR__
  LD_printString_6x8("DS on pin: ", LCDX1, 5);
#else
  LD_printString_6x8("DS: ", LCDX1, 5);
#endif

  for (int i = 0; i < nSensor; i++) {
    //ds18b20[i].init(DS_CONVTIME);
    ds18b20[i].initavg(DS_CONVTIME);
    mb.addHreg(hrTEMP + i); // Модбас регистр - значение температуры
    int pins[] = {DSPINS};
    LD_printNumber((long)pins[i]);
    if (i < (nSensor - 1))
      LD_printChar_6x8(", ");
#ifdef SERIAL_CONFIG
    ds18b20[i].printConfig();
    String sInfo = "ID " + String(i, DEC) + "|Connected " +
                   String(ds18b20[i].Connected, DEC);
    Serial.println(sInfo);
#endif
#ifdef SERIAL_DEBUG
    mb.addHreg(hrDSDEBUG + i); // Модбас регистр - длительность преобразования
#endif
  }

#elif defined(DHTPIN)
  dht.read();
  dht.getHumidity();
  dht.getTemperature();
  mb.addHreg(hrTEMP);
#endif
}

void updateDS(int i)
{
#ifdef DSPINS
  //  ds18b20[i].check();
  //  float t = ds18b20[i].Temp;
  float t = ds18b20[i].getTemp(); // check() + adjust() + calculate and return
                                  // AVERAGE temperature
  mb.Hreg(hrTEMP + i, round(t * 100)); // заносим в регистр Modbus (T * 100)
  dtostrf(t, 5, 1, cbuf);
  display_String(cbuf, 0, (i * 3));
  if (ds18b20[i].Parasite)
    LD_printChar_6x8("`");
  else
    LD_printChar_6x8(" ");
#ifdef SERIAL_INFO
  String dsInfo = "DS " + String(i, DEC) + ": " + String(t, 2) +
                  " | parasite: " + String(ds18b20[i].Parasite, DEC) + " | " +
                  String(ds18b20[i].TimeConv, DEC);
  Serial.println(dsInfo);
#endif
#ifdef SERIAL_DEBUG
  mb.Hreg(hrDSDEBUG + i, ds18b20[i].TimeConv); // DEBUG!
#endif
#elif defined(DHTPIN)
  // Update в функции updatePressure() (так получилось ;-)
#endif
}
