
#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "declarations.h"
#include "display.h"
#include "esp.h"
#include "functions.h"
#include "macros.h"

#if defined(ETHERNET_ENC28J60)
#include "EtherCard.h"
#include "ModbusIP_ENC28J60.h"
//#define MAC1 0x28               // если второй байт адреса равен 28 -
//скомпилировано под enc28j60 #define MAC2 0x60               // на всякий
//случай, чтобы по второму (после старшего) байту MAC адреса
#elif defined(ETHERNET_WIZ5100) // можно было определить под какой шилд
                                // скомпилирован скетч
#include "Ethernet.h"
#include "ModbusIP.h"
//#define MAC1 0x51 // если второй байт адреса равен 51 - скомпилировано под
// wiz5100 #define MAC2 0x00
#endif // ETHERNET_*

ModbusIP mb;

/*
#if defined(ETHERNET_ENC28J60) || defined(ETHERNET_WIZ5100)
uint8_t mac[] = {ETHERNET_MAC};
#endif
*/

void setupNetMB() // Config Modbus IP
{
  uint8_t mac[] = {ETHERNET_MAC};
  serialMAC(mac);
  displayMAC(mac);
  initETH(mac);
  serialIP();
  displayIP();
}

void initETH(uint8_t* mac)
{
#if defined(ETHERNET_ENC28J60) || defined(ETHERNET_WIZ5100)

#ifdef ETHERNET_DHCP
  mb.config(mac);
#else
  uint8_t ip[] = {ETHERNET_IP};
  mb.config(mac, ip);
#endif // ETHERNET_DHCP

#elif defined(ESP32) || defined(ESP8266)
  initWiFi();
#endif // ETH/ESP

  return;
}

void serialMAC(uint8_t* mac)
{
#ifdef SERIAL_CONFIG
#if defined(ETHERNET_ENC28J60) || defined(ETHERNET_WIZ5100)
  Serial.print("MAC: ");
  for (byte i = 0; i < 6; ++i) {
    Serial.print(mac[i], HEX);
    if (i < 5)
      Serial.print(':');
  }
  Serial.println();
#endif
#endif
}

void displayMAC(uint8_t* mac)
{
#if defined(ETHERNET_ENC28J60) || defined(ETHERNET_WIZ5100)
  LD_printString_6x8("MAC: ", LCDX1, 1);
  for (byte i = 0; i < 6; ++i) {
    char mh[2];
    String macStr = String(mac[i], HEX);
    macStr.toUpperCase();
    macStr.toCharArray(mh, 3);
    LD_printChar_6x8(mh);
    if (i < 5)
      LD_printChar_6x8(":");
  }
#endif
}

void serialIP()
{
#ifdef SERIAL_CONFIG
#if defined(ETHERNET_ENC28J60)
  ether.printIp("NC28J60 IP: ", ether.myip);
  ether.printIp("MASK: ", ether.netmask);
  ether.printIp("GW: ", ether.gwip);
  // ether.printIp("DNS: ", ether.dnsip);
#elif defined(ETHERNET_WIZ5100)
  Serial.print(F("WIZ5100 IP: "));
  Serial.println(Ethernet.localIP());
#elif defined(ESP32) || defined(ESP8266)
  esp_serialIP();
#endif
#endif
}

void displayIP()
{
#if defined(ETHERNET_ENC28J60)
  LD_printString_6x8("enc_IP: ", LCDX1, 3);
  for (byte i = 0; i < 4; ++i) {
    LD_printNumber((long)ether.myip[i]);
    if (i < 3)
      LD_printChar_6x8(".");
  }
#elif defined(ETHERNET_WIZ5100)
  LD_printString_6x8("wiz_ip: ", LCDX1, 3);
  for (byte i = 0; i < 4; ++i) {
    LD_printNumber((long)Ethernet.localIP()[i]);
    if (i < 3)
      LD_printChar_6x8(".");
  }
#elif defined(ESP32) || defined(ESP8266)
  esp_diplayIP();
#endif
}
