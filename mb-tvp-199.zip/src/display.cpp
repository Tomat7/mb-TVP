
#include "display.h"

#include "Arduino.h"
#include "config.h"
#include "config_plc.h"

// ===
#ifdef USE_OLED
#include "ASOLED.h"
ASOLED LD(SH1106, 100000);
#ifndef LCDX1
#define LCDX1 0 // смещение 1-го "столбца" на экране
#endif
#ifndef LCDX2
#define LCDX2 65 // смещение 2-го "столбца" на экране
#endif

#endif // USE_OLED

// ===
#ifdef USE_LCD
#include "LiquidCrystal_I2C.h"
LiquidCrystal_I2C
    LCD(0x27, 20,
        4); // set the LCD address to 0x27 for a 16 chars and 2 line display
#ifndef LCDX1
#define LCDX1 0 // смещение 1-го "столбца" на экране
#endif
#ifndef LCDX2
#define LCDX2 10 // смещение 2-го "столбца" на экране
#endif
#endif // USE_LCD

char cbuf[] = {"     "};
const char degC = 223;

void display_Init()
{
#ifdef USE_OLED
  LD.init();
#endif
#ifdef USE_LCD
  LCD.init();
  LCD.backlight();
#endif
}

void display_Clear()
{
#ifdef USE_OLED
  LD.clearDisplay();
#endif
#ifdef USE_LCD
  LCD.clear();
#endif
}

void display_String(String str0)
{
#ifdef USE_LCD
  LCD.print(str0);
#endif
}

void display_String(String str0, int X, int Y)
{
#ifdef USE_OLED
  LD.printString_12x16(str0.c_str(), X, Y);
#endif
#ifdef USE_LCD
  LCD.setCursor(X, Y);
  LCD.print(str0);
#endif
}
