
#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "display.h"
#include "functions.h"
#include "macros.h"

bool relayON = false;
int16_t tickToRelayOff = 0;

#ifdef SMART_RELAY

void setDelay(uint16_t minutesON)
{
  tickToRelayOff = (int16_t)(minutesON * 60 * 1000 / DS_CONVTIME);
  return;
}

void checkTicks()
{
#ifdef GATE_RELAY
  static bool relayPrev;
  relayPrev = relayON;
  if (tickToRelayOff > 1) {
    relayON = true;
    tickToRelayOff--;
  }
  else {
    relayON = false;
    tickToRelayOff = 0;
  }

  mb.Hreg(hrDSCONVTIME, tickToRelayOff);

  if (relayPrev && !relayON)
    setRelayMode(RELAY_OFF);

  return;
#endif // GATE_RELAY
}

void updateRelay()
{
  if (!modbusON || relayON)
    setLedStatus(MODE_LOCAL);
  else if (!wifiConnectOK)
    setLedStatus(MODE_SEARCH_WIFI);
  else if (!mbMasterOK)
    setLedStatus(MODE_MODBUS_WAIT);
  else
    setLedStatus(MODE_MODBUS_OK);

  if (relayON)
    setRelayMode(RELAY_ON);
  else if (mbMasterOK && modbusON)
    setRelayMode(mb.Hreg(hrCLOSE + 3), mb.Hreg(hrOPEN + 3));
  else
    setRelayMode(RELAY_OFF);

  return;
}

void setLedStatus(uint16_t msOff, uint16_t msOn)
{
  const int i = IDX_INFOLED;
  byte hrOpen = hrOPEN + i * 3;
  byte hrClose = hrCLOSE + i * 3;
  // byte hrClicks = hrCLICKS + i * 3;
  valve[i].setTime(msOff, msOn);
  mb.Hreg(hrOpen, msOn);
  mb.Hreg(hrClose, msOff);
  return;
}

void setRelayMode(uint16_t msOff, uint16_t msOn)
{
  const int i = IDX_RELAY;
  byte hrOpen = hrOPEN + i * 3;
  byte hrClose = hrCLOSE + i * 3;
  // byte hrClicks = hrCLICKS + i * 3;
  valve[i].setTime(msOff, msOn);
  mb.Hreg(hrOpen, msOn);
  mb.Hreg(hrClose, msOff);
  return;
}

#endif // SMART_RELAY
