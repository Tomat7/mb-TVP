
#include "Arduino.h"
#include "config.h"
#include "config_net.h"
#include "config_plc.h"
#include "display.h"
#include "functions.h"
#include "macros.h"

#ifdef PRESSURE_BMP
#include "BMP280x.h"
BMP280x bmp280(BMP280_ADDRESS);
#endif

#ifdef PRESSURE_MPX
#include "ADCmulti.h"
ADCmulti mpx5010dp(MPX5010_PIN);
// int Pins[] = { MPX5010_PIN };
// int Vals[] = { &mpxRAW };
#endif

void initPressure()
{
  mb.addHreg(hrPRESSURE); // Давление - атмосферное или избыточное (даже если
                          // без датчиков)
#ifdef PRESSURE_BMP
  bmp280.init();
#elif defined(PRESSURE_MPX)
  mpx5010dp.init();
#endif
}

void updatePressure()
{
#ifdef PRESSURE_BMP
  updBMP();
#elif defined(PRESSURE_MPX)
  updMPX();
#elif defined(DHTPIN)
  updDHT();
#endif
}

#ifdef PRESSURE_BMP
void updBMP()
{
  bmp280.check();
  mb.Hreg(hrPRESSURE, bmp280.Press_mmHg);
  dtostrf(mb.Hreg(hrPRESSURE), 5, 0, cbuf);
  display_String(cbuf, LCDX2, 3);
#ifdef SERIAL_INFO
  String pInfo = "TEMP " + String(bmp280.Temp_C, 2) +
                 " DegC  PRESS : " + String(bmp280.Press_Pa, DEC) + " Pa | " +
                 String(bmp280.Press_mmHg, DEC) + " mmHg";
  Serial.println(pInfo);
#endif
  return;
}
#endif

#ifdef PRESSURE_MPX
void updMPX()
{
  mpx5010dp.check();
  int Press_mmHg = mpx5010dp.read();
  mb.Hreg(hrPRESSURE, Press_mmHg);
  Press_mmHg = (Press_mmHg * 4 - 160) / 50;
  dtostrf(Press_mmHg, 5, 0, cbuf);
  display_String(cbuf, LCDX2, 3);
#ifdef SERIAL_INFO
  String pInfo = "OverPressure: " + String(Press_mmHg, DEC) + " mmHg";
  Serial.println(pInfo);
#endif
  return;
}
#endif

#ifdef DHTPIN
void updDHT()
{
  float t, h;
  int si7021 = dht.read();
  if (si7021 != DHTLIB_WAITING_FOR_READ) {
    if (si7021 == DHTLIB_OK) {
      h = dht.getHumidity();
      t = dht.getTemperature();
    }
    else {
      h = 0.0;
      t = -99.0;
    }
    mb.Hreg(hrPRESSURE, round(h));
    mb.Hreg(hrTEMP, round(t * 100.0));
  }
  return;
}
#endif
