/*
        DStemp.cpp - Library to operate with DS18B20
        Created by Tomat7, 2017-2024.
*/
/*
        check() returns NOTHING!
        only check for temperature changes from OneWire sensor and update Temp

        -99  - sensor not found
        -82  - sensor was found but conversation not finished within defined
               timeout (may be)
        -71  - sensor was found but CRC error (often)
        -59  - sensor was found but something going wrong during conversation

        Connected == 0 значит датчика нет - no sensor found
        в dsMillis хранится millis() c момента запроса или крайнего Init()
        и от dsMillis отсчитывается msConvTimeout
*/

// See updates on https://github.com/Tomat7/DStemp
// Review branches test* for datails, comments and debug options

#include "DStemp.h"
#include "Arduino.h"
#include <OneWire.h>

/*
#if defined(__AVR__)
        #define IF_AVR(...) (__VA_ARGS__)
        #else
        #define IF_AVR(...)
#endif

#if defined(ESP32) || defined(ESP8266)
        #define IF_ESP(...) (__VA_ARGS__)
        #else
        #define IF_ESP(...)
#endif
*/

DSThermometer::DSThermometer(uint8_t pin) : ow(pin) {
  _pin = pin;
  _msConvTimeout = DS_CONV_TIMEOUT;
}

void DSThermometer::init(uint16_t convtimeout) {
  _msConvTimeout = convtimeout;
  ds_init();
}

bool DSThermometer::check() {
  uint16_t msConvDuration = millis() - dsMillis;

  if (Connected && (ow.read_bit() == 1)) // вроде готов отдать данные
  {
    Temp = ds_get_temp(); // возможно -71 (CRC error) или -59 (other error)
    TimeConv = msConvDuration;
  } else if (msConvDuration > _msConvTimeout) // был подключен, но успел
    Temp = DS_T_ERR_TIMEOUT; // -82, датчик был, но оторвали на ходу
  else
    return false;

  if (Temp > DS_T_MIN)
    ds_request();
  else
    ds_init();

  return true;
}

void DSThermometer::printConfig() {
  Serial.println(LibConfig());
  return;
}

String DSThermometer::LibConfig() {
  return LibVersion + " on pin " + String(_pin);
}
